package com.example.music;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class HistoryActivity extends AppCompatActivity {

    private ArrayList<String> musicHistoryAllList;
    private ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        listView = findViewById(R.id.listHistory);

        musicHistoryAllList = new ArrayList<>();

        Intent intent = getIntent();
        musicHistoryAllList = intent.getStringArrayListExtra("musicHistoryAllList");

        ArrayList<String> newList = new  ArrayList<>();

        if (musicHistoryAllList != null) {
            for (String cd : musicHistoryAllList) {
                if(!newList.contains(cd)){
                    newList.add(cd);
                }
            }
        }


        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                HistoryActivity.this,
                R.layout.list_item,
                newList
                );
        listView.setAdapter(adapter);
    }
}
