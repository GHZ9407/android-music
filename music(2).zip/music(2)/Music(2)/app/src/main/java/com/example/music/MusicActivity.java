package com.example.music;

import android.app.ActionBar;
import android.app.Dialog;
import android.content.Intent;
import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MusicActivity extends AppCompatActivity implements View.OnClickListener{

    private TextView textView;

    private MediaPlayer mediaPlayer;
    private TextView tv_start;
    private TextView tv_end;
    private TextView tv;
    private SeekBar seekbar;
    private String item;
    private Integer position;
    private String musicPath = "/mnt/sdcard/netease/cloudmusic/Music/";
    private ArrayList<String> musicList;
    private ArrayList<String> musicHistoryList;
    private ImageButton up;
    private ImageButton play;
    private ImageButton next;

    @Override
    public void onBackPressed() {
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            mediaPlayer.pause();
            mediaPlayer.stop();
        }
        finish();
        super.onBackPressed();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_music);


        //开始时间
        tv_start = (TextView) findViewById(R.id.tv_start);
        //结束时间
        tv_end = (TextView) findViewById(R.id.tv_end);
        //进度条
        seekbar = (SeekBar) findViewById(R.id.seekbar);
        up = findViewById(R.id.bt_previous);
        play = findViewById(R.id.bt_media);
        next = findViewById(R.id.bt_next);
        up.setOnClickListener(this);
        play.setOnClickListener(this);
        next.setOnClickListener(this);


        //设置监听
        seekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                //获取音乐总时间
                int duration2=mediaPlayer.getDuration()/1000;
                //获取音乐当前播放的位置
                int position=mediaPlayer.getCurrentPosition();
                //开始时间
                tv_start.setText(calculateTime(position/1000));
                //结束时间
                tv_end.setText(calculateTime(duration2));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                int progress=seekBar.getProgress();
                //在当前位置播放
                mediaPlayer.seekTo(progress);
            }
        });
        musicList = new ArrayList<>();
        musicHistoryList = new ArrayList<>();

        Intent intent=getIntent();
        item =intent.getStringExtra("item");
        position =intent.getIntExtra("position", 0);
        musicList = intent.getStringArrayListExtra("musicList");
        musicPath = intent.getStringExtra("musicPath");
        System.out.println(musicList.get(position) + "//////////");
        System.out.println(item + "//////////");
        System.out.println(position + "//////////");
        musicHistoryList.add(item);
        System.out.println(musicHistoryList);

        tv = (TextView) findViewById(R.id.sings_name);
        tv.setText(item);

        Intent intentToHistory = new Intent(MusicActivity.this, MainActivity.class);
        Bundle bundle = new Bundle();
        bundle.putStringArrayList("musicHistoryList", musicHistoryList);
        intentToHistory.putExtras(bundle);
        setResult(2, intentToHistory);

    }


    //按钮点击事件
    public void onClick(View view) {
        if (view.getId() == R.id.bt_media) {
            ImageButton imageButton= (ImageButton) view;
            //判断音频文件是否为空
            if(mediaPlayer==null){

                changeMusic(position);
                //音乐文件正在播放，则暂停并改变按钮样式
                imageButton.setImageResource(android.R.drawable.ic_media_pause);
            }
            else if(mediaPlayer.isPlaying() && mediaPlayer != null){
                mediaPlayer.pause();
                imageButton.setImageResource(android.R.drawable.ic_media_play);
            } else{
                //启动播放
                mediaPlayer.start();
                imageButton.setImageResource(android.R.drawable.ic_media_pause);
            }
        } else if (view.getId() == R.id.bt_previous){
            changeMusic(--position);
            play.setImageResource(android.R.drawable.ic_media_pause);
            tv = (TextView) findViewById(R.id.sings_name);
            tv.setText(musicList.get(position));
        } else if (view.getId() == R.id.bt_next) {
            changeMusic(++position);
        }
    }

//    private void initMediaPlayer(int songNum) {
//        if (mediaPlayer != null) {
//            mediaPlayer.reset();
//        }
//    }

    public void changeMusic(int index) {
        System.out.println("index+++++++++" + index);
        System.out.println("position+++++++++" + position);
        if (index < 0) {
            position = index = musicList.size() - 1;
        } else  if (index > musicList.size() - 1) {
            position = index = 0;
        }
        System.out.println("position----------" + position);
        System.out.println("index-----------" + index);
        System.out.println("musicPath-----------" + musicPath);
        System.out.println("musicList-----------" + musicList);

        if (mediaPlayer == null) {
            mediaPlayer = new MediaPlayer();
        }

        try {
            // 切歌之前先重置，释放掉之前的资源
            mediaPlayer.reset();
            // 设置播放源
            mediaPlayer.setDataSource(musicPath + "/" + musicList.get(index));
            // 开始播放前的准备工作，加载多媒体资源，获取相关信息
            mediaPlayer.prepare();
            mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp) {
                    mediaPlayer.start();
                }
            });
            mediaPlayer.setLooping(true);

            // 开始播放
//            mediaPlayer.start();
        } catch (IOException e) {
            e.printStackTrace();
        }
        seekbar.setProgress(0);
        seekbar.setMax(mediaPlayer.getDuration());
        play.setImageResource(android.R.drawable.ic_media_pause);
        tv = (TextView) findViewById(R.id.sings_name);
        tv.setText(musicList.get(position));
        musicHistoryList.add(musicList.get(position));
        new MyThread().start();

    }

    class MyThread extends Thread{
        @Override
        public void run() {
            super.run();
            while(seekbar.getProgress()<=seekbar.getMax()){

                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                //获取音乐当前播放的位置
                int position=mediaPlayer.getCurrentPosition();
                //放入SeekBar中
                seekbar.setProgress(position);
            }
        }
    }

    //计算播放时间
    public String calculateTime(int time){
        int minute;
        int second;
        if(time>=60){
            minute=time/60;
            second=time%60;
            return minute+":"+second;
        }else if(time<60){
            second=time;
            return "0:"+second;
        }
        return null;
    }


}
